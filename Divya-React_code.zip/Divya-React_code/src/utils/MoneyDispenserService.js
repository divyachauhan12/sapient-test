
let currencyNotes = [1,2,5,10,20,50,100,200,500,2000];

class MoneyDispenserService {

    constructor(amount = 0) {
        this.amount = amount;
        this.notesList = {};
        this.noteCount = 0;
    }

    defaultNotesList() {
        currencyNotes.forEach((key) => {
            this.notesList[key] = 0;
        })
    }

    getNotes() {
        this.defaultNotesList();
        this.noteCount = 0;
        this.breakNotesList(this.amount);
        return this.getNotesListArary();
    }

    getNotesListArary() {
        let noteListArray = {};
        let noteKeys = Object.keys(this.notesList);
        noteListArray = noteKeys.map(note => ({
            note,
            count: this.notesList[note]
        }))
        return noteListArray
    }

    breakNotesList(amount) {
        if(amount > 0) {
            let note = this.noteIndex(amount);
            amount -= note;
            this.addNote(note);            
            return this.breakNotesList(amount);
        }        
    }

    addNote(note) {
        if(this.notesList[note]) {
            this.notesList[note] += 1;
        } else {
            this.notesList[note] = 1;
        }
        this.noteCount += 1;
    }

    noteIndex(amount) {
        let note = 0;
        for(let i = currencyNotes.length-1; i >= 0; i--) {
            note = currencyNotes[i];
            if(amount >= note) break;
        }
        return note; 
    }

}

export default MoneyDispenserService;