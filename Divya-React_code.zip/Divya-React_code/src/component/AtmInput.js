import React from 'react';
import GetMoney from './GetMoney';

function AtmInput(props) {
    return (
        <div className="AtmInput-back">
           <h2 className="AtmInput-header"> Welcome to ATM</h2>
           <GetMoney {...props}/>
        </div>
    )
}


export default AtmInput;