import React from 'react'

class GetMoney extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            amount: ""
        }
    }

    onInputChange(e) {
        let {target} = e;
        let {value: amount} = target;
        this.setState({amount});
    }   

    render() {
        let {amount} = this.state;
        let {storeAmount} = this.props;
        return (
            <form className="GetMoney-form" onSubmit={e => storeAmount(e, amount)}>
                <label> Enter the Amount</label>
                <input type="text" onChange={e => this.onInputChange(e)} value={amount} />
                <input type="submit" value="Get Money" />
            </form>  
        )
    }
}

export default GetMoney;
