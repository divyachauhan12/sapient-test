import React from 'react';

export default function NotesList(props) {
    let {moneyList} = props;     
    return (
        <div className="note-count-list">
            {moneyList.map((list, key) => <p className="note-count-item" key={key}> 
                {list.count} notes of Rs {list.note}
            </p>)}
        </div>
    )
}