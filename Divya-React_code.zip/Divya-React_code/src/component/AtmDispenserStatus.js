import React from 'react';
import NotesList from './NotesList'
import MoneyDispenserService from '../utils/MoneyDispenserService'

function AtmDispenserStatus(props) {
    let {amount} = props;   
    let moneyService = new MoneyDispenserService(amount);
    let moneyList = moneyService.getNotes();                                
    return (<div className="notes-status-cont">
        <p className="heading"> You will get following amount</p>
        <NotesList moneyList={moneyList}/>
        <p className="heading"> Total notes dispensed: {moneyService.noteCount}</p>
    </div>)
}


export default AtmDispenserStatus;