import React from 'react';
import AtmInput from './AtmInput';
import AtmDispenserStatus from './AtmDispenserStatus'

class AtmDispenser extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            withDrawAmount: 0
        }
    }

    storeAmount = (e, amount) => {
        e.preventDefault();
        amount = parseInt(amount);
        this.setState({withDrawAmount: amount});
    }
    

    render() {
        let {withDrawAmount} = this.state;
        return (<div className="AtmDispenser-back">
            <AtmInput storeAmount={this.storeAmount}/>
            <AtmDispenserStatus amount={withDrawAmount}/>
        </div>)
    }
}

export default AtmDispenser;