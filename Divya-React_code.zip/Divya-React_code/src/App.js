import React, { Component } from 'react';
import './App.css'; 
import AtmDispenser from './component/AtmDispenser';

class App extends Component {
  render() {
    return (
      <div className="App">
        <h1 className="App-header"> ATM Money Dispenser</h1>
        <AtmDispenser />
      </div>
    );
  } 
}

export default App;
